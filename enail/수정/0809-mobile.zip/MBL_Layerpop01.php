
    <script src="js/popup.js"></script>


            
    <div class="popup">
        <div class="popup-cont">
            <h3>e내일신문 서비스 안내<span></span></h3>
            <p>
                신문에 실리지 않는 사건의 이면, 지면 제약에서 벗어난 심층 분석 기사를 e내일신문을 통해 선보입니다.<br><br>
                e내일신문 서비스는 내일신문 홈페이지에서'e-내일신문'구독 신청을 하신 회원 대상으로 이용 가능합니다.<br><br>
                구독 신청 후 e내일신문 홈페이지 이용 바랍니다.<br><br>
                감사합니다.
            </p>
            <a href="#">홈페이지 바로가기</a>
        </div>
        
        <div class="popup-checkbox">
            <label class="cb">
                 <input type="checkbox" value="">
                 <span></span>
                 <p>오늘 하루 열지 않기</p>
            </label>
        </div>
    </div>