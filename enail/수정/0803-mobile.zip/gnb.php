    <header>
        <div class="gnb">
            <div class="gnb-title on"><a href="#">기자리포트</a></div>
            <div class="gnb-ham"></div>
            <div class="gnb-logo"><a href="#"></a></div>
            <div class="gnb-search searchboxlong"></div>
        </div>
    </header>

    <div class="gnb-searchbox">
        <div class="searchbox01">
            <input type="text" id="searchtextbox" value="" placeholder="찾으시는 검색어를 입력하세요.">
            <div></div>
        </div>
        <div class="searchbox02">
            <h3>추천검색어</h3>
            <div></div>
            <ul>
                <li><a href="#">세종시 주상복합</a></li>
                <li><a href="#">병역회피</a></li>
                <li><a href="#">문재인대통령</a></li>
                <li><a href="#">역지사지</a></li>
                <li><a href="#">일본식차지차가법</a></li>
            </ul>
        </div>
    </div>

    <div class="wrap-black"></div>
    
    <div class="left-gnb">
        <ul class="left-gnb-logo clear">
            <li><a href="#"></a></li>
            <li class="left-gnb-close"></li>
        </ul>
        <ul class="left-gnb-btn clear">
            <li><a href="#">마이페이지</a></li>
            <li><a href="#">로그아웃</a></li>
        </ul>
        <ul class="left-gnb-menu">
            <li><a href="#">뉴스보기</a></li>
            <li><a href="#">신문(PDF)</a></li>
            <li><a href="#">기자리포트</a></li>
            <li><a href="#">스페셜리포트</a></li>
            <li><a href="#">동영상뉴스</a></li>
            <li><a href="#">내일봇</a></li>
            <li><a href="#">지역내일</a></li>
            <li><a href="#">대학내일</a></li>
            <li><a href="#">미즈내일</a></li>
        </ul>
    </div>
    
    <div class="footer-top"></div>