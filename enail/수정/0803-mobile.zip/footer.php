<footer>
    <ul class="footer-btn clear">
        <li><a href="#">PC보기</a></li>
        <li>
           패밀리사이트
           <img src="img/gnb/footer-family01.jpg">
           <img src="img/gnb/footer-family02.jpg">
            <ul class="footer-family-btn">
                <li><a href="#">지역내일</a></li>
                <li><a href="#">미즈내일</a></li>
                <li><a href="#">대학내일</a></li>
            </ul>
        </li>
    </ul>
    <div class="footer-cont">
        <div class="footer-logo"></div>
        <p>
            (주)내일신문 서울특별시 중구 통일로 92, 13층 (순화동, 에이스타워)<br>
            대표 장명국 사업자등록번호 111-81-19851 전화 02-2287-2300<br>
            웹사이트 운영대행사 : (주)내일이비즈 101-86-52538<br><br>
            Copyright ©내일신문 All rights reserved.
        </p>
    </div>
</footer>